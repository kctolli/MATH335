library(tidyverse)
library(USAboundaries)
library(USAboundariesData)
library(leaflet)

covid19 <- read_csv("https://github.com/CSSEGISandData/COVID-19/raw/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_confirmed_global.csv")

covidnew <- read_csv("https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_confirmed_US.csv") %>% 
  rename(confirmed = `3/30/2020`)

covid_top20<- covidnew %>% arrange(desc(confirmed)) %>% top_n(20) %>% select(confirmed, everything())

covid_states_long <- covid %>% filter(Province_State %in% state.name) %>% 
  select(Province_State, confirmed, `3/1/2020`, `3/8/2020`, `3/15/2020`) %>% 
  group_by(Province_State) %>% 
  summarise(most_recent = sum(confirmed),
            Mar1 = sum(`3/1/2020`),
            Mar8 = sum(`3/8/2020`),
            Mar15 = sum(`3/15/2020`)) %>% 
  pivot_longer(cols = c(most_recent, Mar1, Mar8, Mar15), values_to = "cases", names_to = "when")

states48 <- USAboundaries::us_states() %>%  
  filter(name != "Alaska" & name != "Hawaii" & name != "Puerto Rico")

covid_lay_long <- inner_join(covid_states_long, states48, by = c("Province_State" = "name")) %>% filter(when == "Mar8" | when =="Mar15")

population_18 <- read_csv("population_2018.csv") %>% 
  mutate(population_100000 = (Population / 100000)) %>% 
  rename(state = "State")

covid <- covid19 %>% select("Province/State", Lat, Long, "3/24/20", "3/22/20") %>% 
  rename(state = "Province/State", confirmed_today = "3/24/20", confirmed_yesterday = "3/22/20") %>% 
  filter(state %in% state.name) %>% 
  mutate(difference = (confirmed_today - confirmed_yesterday))

covid_pop <- inner_join(covid, population_18, by = "state") %>% 
  mutate(case_per_100k = round((difference / population_100000), digits=2))

states48 <- us_states() %>% filter(name != "Alaska" & name != "Hawaii" & name != "Puerto Rico")

covid_state <- inner_join(states48, covid_pop, by = c("name" = "state"))

ggplot(data = covid_state) +
  geom_sf(fill = "white", color = "red") + 
  geom_text(aes(label = case_per_100k, geometry = geometry), stat = "sf_coordinates", color = "black") +
  theme_bw() + 
  theme(axis.title.x = element_blank(),
        axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank()) 

ggsave("COVID.png", 
       scale = 4,
       width = 7,
       height = 7,
       units = "in")

write.csv(covid_state, "covid_data.csv")


leaflet(data=covid_top20) %>% addTiles() %>% 
  setView(lng = -99, lat = 40, zoom = 4) %>% 
  addMarkers(lng = ~Long_, lat = ~Lat, label = ~paste0(Admin2," County = ", confirmed , " confirmed cases"))

leaflet(data=covid_top20) %>% addTiles() %>% 
  setView(lng = -99, lat = 40, zoom = 4) %>% 
  addCircles(lng = ~Long_, lat = ~Lat, 
             radius = ~confirmed,
            label = ~paste0(Admin2," County = ", confirmed , " confirmed cases"))

leaflet(data=covid_top20) %>% addTiles() %>% 
  setView(lng = -99, lat = 40, zoom = 4) %>% 
  addCircleMarkers(lng = ~Long_, lat = ~Lat, 
             radius = ~log(confirmed),
             label = ~paste0(Admin2," County = ", confirmed , " confirmed cases"))


leaflet(data=covid_top20) %>% addTiles() %>% 
  setView(lng = -99, lat = 40, zoom = 4) %>% 
  addCircles(lng = ~Long_, lat = ~Lat, 
             radius = ~sqrt(confirmed)*500,
             label = ~paste0(Admin2," County = ", confirmed , " confirmed cases"), 
             fillOpacity = .1)

pal<-colorNumeric(palette = c("yellow", "red"), domain = log(covid_top20$confirmed))

pal <- colorNumeric(palette = c("white", "orange", "red"),
                        domain = min(covid_lay_long$cases):max(covid_lay_long$cases))




leaflet() %>% 
  setView(lng = -99, lat = 40, zoom = 4) %>% 
  addProviderTiles(providers$Esri.NatGeoWorldMap) %>%
  
  addPolygons(data = st_as_sf(filter(covid_lay_long, when=="Mar8")),
                          group = "March 8th",
                          fillOpacity = .5,
                          fillColor = ~pal(Mar8)) %>% 
  addPolygons(data = st_as_sf(filter(covid_lay_long, when == "Mar15")),
                    group = "March 15th",
                    fillOpacity = .5,
                    fillColor = ~pal(Mar15)) %>% 
            addLayersControl(
              baseGroups = c("March 8th", "March 15th"),
              #overlayGroups = c("Quakes", "Outline"),
              options = layersControlOptions(collapsed = FALSE))
          