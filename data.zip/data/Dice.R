x <- ceiling(runif(1, min = 1, max = 6))
y <- ceiling(runif(1, min = 1, max = 6))

z <- x + y

z